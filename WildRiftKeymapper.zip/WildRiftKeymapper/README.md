# WR Keymapper (Wild Rift keyboard + mouse mapper)

Maps a physical keyboard and mouse to touch input for League of Legends: Wild Rift.
No root needed; it uses an Android Accessibility Service.

> Status: written but NOT compiled or tested on a device (no Android SDK where it was
> generated). Expect to fix a few build errors and to tune the settings on your phone.

## Build

1. Install Android Studio (Ladybug or newer) and open the `WildRiftKeymapper` folder.
2. Let Gradle sync (it downloads AGP 8.7.3, Kotlin 2.0.21, Compose).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   The APK is in `app/build/outputs/apk/debug/app-debug.apk`.

## First run

1. Install the APK, open **WR Keymapper**.
2. Tap **Accessibility**, enable WR Keymapper. On Android 13+ you may first need
   **App info > three dots > Allow restricted settings**.
3. Plug in / pair keyboard and mouse.
4. Tap **Open Wild Rift + layout editor**. After the game loads, drag each marker
   onto the real on-screen button and press **Save**. Default positions are guesses.

## Controls (defaults)

| Input | Action |
|---|---|
| Mouse move | Moves the virtual cursor (pointer is captured) |
| Right-click (hold) | Walk toward the cursor (drives the movement stick) |
| Left-click | Basic attack |
| Arrow keys | Movement stick (optional alternative) |
| Q / W / E / R | Skills. Default mode: quick cast toward cursor |
| Ctrl + Q/W/E/R | Level up that skill |
| D / F | Summoner spells |
| B | Recall |
| 1 / 2 | Item buttons |
| Space | Basic attack |
| F1 | Mapping on/off |
| ` (grave) | Free cursor: releases the mouse and passes keys through (menus, chat) |
| F3 | Layout editor |

## Accuracy settings

- **Hero position X/Y**: where your champion sits on screen. Aim direction is measured
  from here to the cursor, so set it exactly (the editor has a Hero marker).
- **Cursor distance = full skill range**: how far the cursor must be from the hero to
  drag a skill to its maximum range.
- **Aim drag radius** (per skill): how far the finger drags on the skill ring.
- **Mouse speed X/Y**, **stick radius / push / smoothing**, **right-click dead zone**.
- **Frame length**: smaller = more responsive but heavier on the phone.
- **Minimum tap hold**, **aim settle**: raise if casts misfire or aim is off at release.
- Per-skill **cast mode**: tap/hold, quick cast toward cursor, hold to aim and release to cast.

## How it works / limits

- Keys are read through the accessibility key filter.
- The mouse is read with pointer capture on a non-touchable full-screen overlay, so
  injected touches pass through to the game.
- Touches are injected with `dispatchGesture` as a chain of short continued strokes.
  Android cancels an in-flight gesture when a new one is dispatched, so frames are sent
  back to back. Expect roughly 30-60 ms of input latency, less precise than root/Shizuku tools.
- The overlay holds window focus for pointer capture. If the game pauses or mutes on
  focus loss, turn mapping off with F1 or use the free cursor.
- The mapper activates only while a package from "Game packages" is in the foreground
  (Wild Rift global and the Tencent build by default). If the service is switched on
  while the game is already open, switch away and back once.
- Third-party input injection can conflict with a game's rules or anti-cheat. Use at your own risk.
