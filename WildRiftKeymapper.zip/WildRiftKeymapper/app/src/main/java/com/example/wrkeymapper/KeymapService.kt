package com.example.wrkeymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.hypot

class KeymapService : AccessibilityService(), InputOverlay.Listener {

    companion object {
        @Volatile var instance: KeymapService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var engine: GestureEngine
    private var overlay: InputOverlay? = null
    private var editor: EditorView? = null

    private var gameActive = false
    private var mappingOn = true
    private var freeCursor = false
    private var screenW = 1920f
    private var screenH = 1080f
    private var cursorX = 960f
    private var cursorY = 540f

    private var rightHeld = false
    private val moveDown = BooleanArray(4) // up, down, left, right
    private val activeByKey = HashMap<Int, Pair<Binding, Boolean>>() // key/mouse code -> (binding, wasLevelUp)
    private val holdAim = ArrayList<Binding>()

    private val density get() = resources.displayMetrics.density

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Store.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        engine = GestureEngine(this)
    }

    override fun onInterrupt() {
        releaseAll()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        leaveGame()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "android" ||
            pkg.startsWith("com.android.systemui") || pkg.contains("inputmethod")
        ) return
        val isGame = Store.settings.packageList().contains(pkg)
        if (isGame && !gameActive) enterGame() else if (!isGame && gameActive) leaveGame()
    }

    private fun enterGame() {
        gameActive = true
        mappingOn = true
        freeCursor = false
        refreshMetrics()
        cursorX = screenW / 2f
        cursorY = screenH / 2f
        val ov = InputOverlay(this)
        ov.listener = this
        overlay = ov
        try { wm.addView(ov, overlayParams(true)) } catch (_: Exception) { overlay = null; return }
        syncOverlay()
        toast("Keymapper on  (${keyName(Store.settings.toggleKey)} toggles)")
        if (Store.pendingEditor) {
            Store.pendingEditor = false
            handler.postDelayed({ if (gameActive) openEditor() }, 2500)
        }
    }

    private fun leaveGame() {
        if (!gameActive && overlay == null && editor == null) return
        gameActive = false
        closeEditor(false)
        releaseAll()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    // ---------------------------------------------------------------- overlay windows

    private fun overlayParams(focusable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return baseParams(flags)
    }

    private fun baseParams(flags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun syncOverlay() {
        val ov = overlay ?: return
        val focusable = mappingOn && editor == null
        try { wm.updateViewLayout(ov, overlayParams(focusable)) } catch (_: Exception) {}
        val s = Store.settings
        ov.captureWanted = focusable && !freeCursor
        ov.cursorX = cursorX
        ov.cursorY = cursorY
        ov.heroX = s.charX * screenW
        ov.heroY = s.charY * screenH
        ov.syncCapture()
        ov.invalidate()
    }

    fun openEditor() {
        if (!gameActive || editor != null) return
        releaseAll()
        val ev = EditorView(this, Store.settings) { save -> closeEditor(save) }
        editor = ev
        try {
            wm.addView(
                ev,
                baseParams(
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                )
            )
        } catch (_: Exception) {
            editor = null
            return
        }
        syncOverlay()
    }

    private fun closeEditor(save: Boolean) {
        val ev = editor ?: return
        editor = null
        if (save) {
            ev.applyTo(Store.settings)
            Store.save(this)
            toast("Layout saved")
        }
        try { wm.removeView(ev) } catch (_: Exception) {}
        if (gameActive) syncOverlay()
    }

    @Suppress("DEPRECATION")
    private fun refreshMetrics() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels.toFloat()
        screenH = dm.heightPixels.toFloat()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- keyboard

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!gameActive || editor != null) return false
        val s = Store.settings
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN
        val first = down && event.repeatCount == 0

        if (code == s.toggleKey) { if (first) toggleMapping(); return true }
        if (!mappingOn) return false
        if (code == s.editorKey) { if (first) openEditor(); return true }
        if (code == s.freeKey) { if (first) toggleFree(); return true }
        if (freeCursor) return false // let keys through so in-game chat still works

        val mi = intArrayOf(s.keyUp, s.keyDown, s.keyLeft, s.keyRight).indexOf(code)
        if (mi >= 0) {
            if (!down || event.repeatCount == 0) {
                moveDown[mi] = down
                updateJoystick()
            }
            return true
        }

        val b = s.bindings.firstOrNull { it.keyCode == code } ?: return false
        if (down) {
            if (event.repeatCount == 0) {
                refreshMetrics()
                val lvl = event.isCtrlPressed && b.canLevelUp
                activeByKey[code] = b to lvl
                if (lvl) tapLevelUp(b) else bindingDown(b)
            }
        } else {
            activeByKey.remove(code)?.let { (bb, lvl) -> if (!lvl) bindingUp(bb) }
        }
        return true
    }

    private fun toggleMapping() {
        mappingOn = !mappingOn
        releaseAll()
        syncOverlay()
        toast(if (mappingOn) "Keymapper ON" else "Keymapper OFF")
    }

    private fun toggleFree() {
        freeCursor = !freeCursor
        releaseAll()
        syncOverlay()
        toast(if (freeCursor) "Free cursor (keys pass through)" else "Mouse captured")
    }

    // ---------------------------------------------------------------- mouse

    override fun onMouseMove(dx: Float, dy: Float) {
        if (!mappingOn || freeCursor) return
        val s = Store.settings
        cursorX = (cursorX + dx * s.mouseSensX).coerceIn(0f, screenW - 1f)
        cursorY = (cursorY + dy * s.mouseSensY).coerceIn(0f, screenH - 1f)
        overlay?.let { it.cursorX = cursorX; it.cursorY = cursorY; it.invalidate() }
        if (rightHeld) updateJoystick()
        for (b in holdAim) {
            val (px, py) = pos(b)
            val (tx, ty) = aimTarget(b, px, py)
            engine.move(b.id, tx, ty)
        }
    }

    override fun onMouseButton(button: Int, down: Boolean) {
        if (!mappingOn || freeCursor || editor != null) return
        val s = Store.settings
        when (button) {
            MotionEvent.BUTTON_PRIMARY -> {
                val b = s.bindings.firstOrNull { it.id == s.leftClickBinding } ?: return
                if (down) {
                    refreshMetrics()
                    activeByKey[-1] = b to false
                    bindingDown(b)
                } else {
                    activeByKey.remove(-1)?.let { bindingUp(it.first) }
                }
            }
            MotionEvent.BUTTON_SECONDARY -> if (s.rightClickMove) {
                refreshMetrics()
                rightHeld = down
                updateJoystick()
            }
        }
    }

    // ---------------------------------------------------------------- actions

    private fun pos(b: Binding) = Pair(b.x * screenW, b.y * screenH)

    private fun aimTarget(b: Binding, px: Float, py: Float): Pair<Float, Float> {
        val s = Store.settings
        val ox = cursorX - s.charX * screenW
        val oy = cursorY - s.charY * screenH
        val dist = hypot(ox, oy)
        if (dist < 1f) return Pair(px, py)
        val frac = (dist / (s.cursorRangeDp * density)).coerceAtMost(1f)
        val r = b.aimRadiusDp * density * frac
        return Pair(
            (px + ox / dist * r).coerceIn(0f, screenW - 1f),
            (py + oy / dist * r).coerceIn(0f, screenH - 1f)
        )
    }

    private fun bindingDown(b: Binding) {
        val s = Store.settings
        val (px, py) = pos(b)
        when (if (b.canAim) b.mode else CastMode.TAP) {
            CastMode.TAP -> engine.down(b.id, px, py, s.tapMinMs.toLong())
            CastMode.QUICK_AIM -> {
                val (tx, ty) = aimTarget(b, px, py)
                engine.down(b.id, px, py, s.frameMs + s.aimSettleMs.toLong())
                engine.move(b.id, tx, ty)
                engine.up(b.id)
            }
            CastMode.HOLD_AIM -> {
                engine.down(b.id, px, py, 0)
                val (tx, ty) = aimTarget(b, px, py)
                engine.move(b.id, tx, ty)
                if (!holdAim.contains(b)) holdAim.add(b)
            }
        }
    }

    private fun bindingUp(b: Binding) {
        val s = Store.settings
        when (if (b.canAim) b.mode else CastMode.TAP) {
            CastMode.TAP -> engine.up(b.id)
            CastMode.QUICK_AIM -> {}
            CastMode.HOLD_AIM -> {
                holdAim.remove(b)
                engine.up(b.id, s.aimSettleMs.toLong())
            }
        }
    }

    private fun tapLevelUp(b: Binding) {
        val s = Store.settings
        val id = "lvl_" + b.id
        engine.down(id, b.x * screenW, (b.y - s.levelUpOffsetY).coerceAtLeast(0.01f) * screenH, s.tapMinMs.toLong())
        engine.up(id)
    }

    private fun updateJoystick() {
        val s = Store.settings
        var vx = 0f
        var vy = 0f
        if (rightHeld && s.rightClickMove) {
            val ox = cursorX - s.charX * screenW
            val oy = cursorY - s.charY * screenH
            val dist = hypot(ox, oy)
            if (dist > s.moveDeadzoneDp * density) {
                vx = ox / dist
                vy = oy / dist
            }
        } else {
            if (moveDown[0]) vy -= 1f
            if (moveDown[1]) vy += 1f
            if (moveDown[2]) vx -= 1f
            if (moveDown[3]) vx += 1f
            val len = hypot(vx, vy)
            if (len > 0f) { vx /= len; vy /= len }
        }
        if (vx == 0f && vy == 0f) {
            engine.up("joy")
            return
        }
        val cx = s.joyX * screenW
        val cy = s.joyY * screenH
        val r = s.joyRadiusDp * density * s.joyPush
        if (!engine.isDown("joy")) engine.down("joy", cx, cy, 0, s.joySmooth)
        engine.move("joy", cx + vx * r, cy + vy * r)
    }

    private fun releaseAll() {
        rightHeld = false
        moveDown.fill(false)
        activeByKey.clear()
        holdAim.clear()
        if (::engine.isInitialized) engine.releaseAll()
    }
}
