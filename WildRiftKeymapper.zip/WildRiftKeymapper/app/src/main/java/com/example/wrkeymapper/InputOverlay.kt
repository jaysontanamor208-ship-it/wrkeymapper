package com.example.wrkeymapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Full-screen, non-touchable overlay. It holds window focus so it can use pointer capture
 * (relative mouse movement, system cursor hidden), and it draws the virtual crosshair.
 * Because it is not touchable, injected touches pass straight through to the game.
 */
class InputOverlay(context: Context) : View(context) {

    interface Listener {
        fun onMouseMove(dx: Float, dy: Float)
        fun onMouseButton(button: Int, down: Boolean)
    }

    var listener: Listener? = null
    var captureWanted = false
    var cursorX = 0f
    var cursorY = 0f
    var heroX = 0f
    var heroY = 0f

    private var lastButtons = 0
    private val dp = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = 2f * dp
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 255, 80, 80); style = Paint.Style.STROKE; strokeWidth = 1.5f * dp
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(230, 255, 60, 60) }

    private val buttonMasks = intArrayOf(
        MotionEvent.BUTTON_PRIMARY, MotionEvent.BUTTON_SECONDARY, MotionEvent.BUTTON_TERTIARY,
        MotionEvent.BUTTON_BACK, MotionEvent.BUTTON_FORWARD
    )

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, ev ->
            handleCaptured(ev)
            true
        }
    }

    private fun handleCaptured(ev: MotionEvent) {
        val buttons = ev.buttonState
        val changed = buttons xor lastButtons
        if (changed != 0) {
            for (mask in buttonMasks) {
                if ((changed and mask) != 0) listener?.onMouseButton(mask, (buttons and mask) != 0)
            }
            lastButtons = buttons
        }
        val a = ev.actionMasked
        if (a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_HOVER_MOVE) {
            // Captured pointers report relative deltas; batched samples must be summed.
            var sx = ev.x
            var sy = ev.y
            for (i in 0 until ev.historySize) {
                sx += ev.getHistoricalX(i)
                sy += ev.getHistoricalY(i)
            }
            if (sx != 0f || sy != 0f) listener?.onMouseMove(sx, sy)
        }
    }

    fun syncCapture() {
        if (!isAttachedToWindow) return
        if (captureWanted) {
            requestFocus()
            if (hasWindowFocus()) requestPointerCapture()
        } else if (hasPointerCapture()) {
            releasePointerCapture()
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) syncCapture()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncCapture()
    }

    override fun onPointerCaptureChange(hasCapture: Boolean) {
        super.onPointerCaptureChange(hasCapture)
        if (!hasCapture) lastButtons = 0
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!captureWanted) return
        canvas.drawLine(heroX, heroY, cursorX, cursorY, line)
        canvas.drawCircle(cursorX, cursorY, 11f * dp, ring)
        canvas.drawCircle(cursorX, cursorY, 2.5f * dp, dot)
    }
}
