package com.example.wrkeymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.abs

/**
 * Turns "finger N is down at X,Y" state into a chain of short gestures.
 *
 * AccessibilityService.dispatchGesture() cancels any gesture still in flight, so every frame
 * contains one continued stroke per held finger, and the next frame is only sent once the
 * previous one completed. That is what lets the joystick finger stay down while skill
 * fingers tap and drag at the same time.
 */
class GestureEngine(private val service: AccessibilityService) {

    private class P(var x: Float, var y: Float) {
        var dx = x                       // where the finger should be
        var dy = y
        var smooth = 0f
        var stroke: GestureDescription.StrokeDescription? = null
        var release = false
        var minUp = 0L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val pointers = LinkedHashMap<String, P>()
    private var inFlight = false

    fun isDown(id: String) = pointers[id]?.release == false

    /** Start a finger at x,y. If it already exists, just cancels a pending release. */
    fun down(id: String, x: Float, y: Float, minHoldMs: Long = 0L, smooth: Float = 0f) {
        val existing = pointers[id]
        if (existing != null) {
            existing.release = false
            return
        }
        val p = P(x, y)
        p.smooth = smooth
        p.minUp = SystemClock.uptimeMillis() + minHoldMs
        pointers[id] = p
        pump()
    }

    fun move(id: String, x: Float, y: Float) {
        pointers[id]?.let { it.dx = x; it.dy = y }
    }

    /** Lift the finger once its minimum hold time (plus afterMs) has passed. */
    fun up(id: String, afterMs: Long = 0L) {
        pointers[id]?.let {
            it.release = true
            it.minUp = maxOf(it.minUp, SystemClock.uptimeMillis() + afterMs)
        }
        pump()
    }

    fun releaseAll() {
        for (p in pointers.values) {
            p.release = true
            p.minUp = 0L
        }
        pump()
    }

    private fun pump() {
        if (inFlight || pointers.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        val frame = Store.settings.frameMs.coerceIn(16, 100).toLong()
        val builder = GestureDescription.Builder()
        val finishing = ArrayList<String>()
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        var count = 0

        for ((id, p) in pointers) {
            if (count >= maxStrokes) break
            val first = p.stroke == null
            var tx = p.x
            var ty = p.y
            if (!first) {
                if (p.smooth > 0f) {
                    tx = p.x + (p.dx - p.x) * (1f - p.smooth)
                    ty = p.y + (p.dy - p.y) * (1f - p.smooth)
                    if (abs(p.dx - tx) < 0.5f && abs(p.dy - ty) < 0.5f) { tx = p.dx; ty = p.dy }
                } else {
                    tx = p.dx
                    ty = p.dy
                }
            }
            val path = Path()
            path.moveTo(p.x, p.y)
            if (tx != p.x || ty != p.y) path.lineTo(tx, ty)

            val ending = p.release && now >= p.minUp
            val prev = p.stroke
            val s = if (prev == null) {
                GestureDescription.StrokeDescription(path, 0, frame, !ending)
            } else {
                prev.continueStroke(path, 0, frame, !ending)
            }
            builder.addStroke(s)
            p.stroke = s
            p.x = tx
            p.y = ty
            if (ending) finishing.add(id)
            count++
        }
        if (count == 0) return

        val gesture = try { builder.build() } catch (e: Exception) { return }
        inFlight = true
        val accepted = service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                inFlight = false
                pump()
            }

            override fun onCancelled(g: GestureDescription?) {
                // Continuity is lost: fingers that were being lifted are dropped, the rest restart.
                inFlight = false
                pointers.values.removeAll { it.release }
                for (p in pointers.values) p.stroke = null
                pump()
            }
        }, handler)
        if (!accepted) {
            inFlight = false
            pointers.clear()
        } else {
            for (id in finishing) pointers.remove(id)
        }
    }
}
