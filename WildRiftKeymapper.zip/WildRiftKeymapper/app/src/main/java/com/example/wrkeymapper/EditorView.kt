package com.example.wrkeymapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.hypot

/**
 * Drag-to-calibrate layer drawn over the game. Each marker is dragged onto the matching
 * on-screen button; Save writes the fractions back into the settings.
 */
class EditorView(
    context: Context,
    private val s: AppSettings,
    private val onClose: (Boolean) -> Unit
) : FrameLayout(context) {

    private class M(val id: String, val label: String, var x: Float, var y: Float, val kind: Int, val radiusDp: Float)

    private val dp = resources.displayMetrics.density
    private val markers = ArrayList<M>()
    private var sel: M? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * dp }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12f * dp; textAlign = Paint.Align.CENTER
        setShadowLayer(3f * dp, 0f, 0f, Color.BLACK)
    }

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.argb(60, 0, 0, 0))
        for (b in s.bindings) markers += M(b.id, b.label, b.x, b.y, 0, if (b.canAim) b.aimRadiusDp else 0f)
        markers += M("joy", "Move stick", s.joyX, s.joyY, 1, s.joyRadiusDp)
        markers += M("hero", "Hero", s.charX, s.charY, 2, 0f)

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val save = Button(context).apply { text = "Save"; setOnClickListener { onClose(true) } }
        val cancel = Button(context).apply { text = "Cancel"; setOnClickListener { onClose(false) } }
        row.addView(save)
        row.addView(cancel)
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
    }

    fun applyTo(target: AppSettings) {
        for (m in markers) {
            when (m.kind) {
                0 -> target.bindings.firstOrNull { it.id == m.id }?.let { it.x = m.x; it.y = m.y }
                1 -> { target.joyX = m.x; target.joyY = m.y }
                2 -> { target.charX = m.x; target.charY = m.y }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best: M? = null
                var bestD = 64f * dp
                for (m in markers) {
                    val d = hypot(m.x * width - e.x, m.y * height - e.y)
                    if (d < bestD) { bestD = d; best = m }
                }
                sel = best
                return best != null
            }
            MotionEvent.ACTION_MOVE -> {
                sel?.let {
                    it.x = (e.x / width).coerceIn(0.01f, 0.99f)
                    it.y = (e.y / height).coerceIn(0.01f, 0.99f)
                    invalidate()
                }
                return sel != null
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { sel = null; return true }
        }
        return false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawText(
            "Drag each marker onto the matching button in the game, then Save",
            width / 2f, 78f * dp, text
        )
        for (m in markers) {
            val cx = m.x * width
            val cy = m.y * height
            val color = when (m.kind) {
                1 -> Color.rgb(80, 200, 255)
                2 -> Color.rgb(255, 90, 90)
                else -> Color.rgb(255, 200, 60)
            }
            fill.color = Color.argb(110, Color.red(color), Color.green(color), Color.blue(color))
            stroke.color = color
            if (m.radiusDp > 0f) canvas.drawCircle(cx, cy, m.radiusDp * dp, stroke)
            canvas.drawCircle(cx, cy, 20f * dp, fill)
            canvas.drawCircle(cx, cy, 20f * dp, stroke)
            canvas.drawText(m.label, cx, cy - 26f * dp, text)
        }
    }
}
