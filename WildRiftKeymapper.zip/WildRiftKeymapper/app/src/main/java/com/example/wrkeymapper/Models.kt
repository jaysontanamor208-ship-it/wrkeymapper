package com.example.wrkeymapper

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

enum class CastMode(val label: String) {
    TAP("Tap / hold while key is down"),
    QUICK_AIM("Quick cast toward cursor"),
    HOLD_AIM("Hold to aim, release to cast")
}

/** One on-screen game button. x/y are fractions of the screen (0..1). */
class Binding(
    val id: String,
    var label: String,
    var keyCode: Int,
    var x: Float,
    var y: Float,
    var mode: CastMode,
    var aimRadiusDp: Float = 100f,
    val canAim: Boolean = false,
    val canLevelUp: Boolean = false
)

fun defaultBindings(): MutableList<Binding> = mutableListOf(
    Binding("attack", "Basic attack", KeyEvent.KEYCODE_SPACE, 0.88f, 0.80f, CastMode.TAP),
    Binding("q", "Skill 1 (Q)", KeyEvent.KEYCODE_Q, 0.76f, 0.88f, CastMode.QUICK_AIM, 100f, true, true),
    Binding("w", "Skill 2 (W)", KeyEvent.KEYCODE_W, 0.77f, 0.70f, CastMode.QUICK_AIM, 100f, true, true),
    Binding("e", "Skill 3 (E)", KeyEvent.KEYCODE_E, 0.87f, 0.58f, CastMode.QUICK_AIM, 100f, true, true),
    Binding("r", "Ultimate (R)", KeyEvent.KEYCODE_R, 0.68f, 0.80f, CastMode.QUICK_AIM, 100f, true, true),
    Binding("d", "Summoner 1 (D)", KeyEvent.KEYCODE_D, 0.96f, 0.58f, CastMode.TAP, 100f, true),
    Binding("f", "Summoner 2 (F)", KeyEvent.KEYCODE_F, 0.96f, 0.42f, CastMode.TAP, 100f, true),
    Binding("recall", "Recall (B)", KeyEvent.KEYCODE_B, 0.60f, 0.92f, CastMode.TAP),
    Binding("item1", "Item 1", KeyEvent.KEYCODE_1, 0.52f, 0.92f, CastMode.TAP),
    Binding("item2", "Item 2", KeyEvent.KEYCODE_2, 0.45f, 0.92f, CastMode.TAP)
)

class AppSettings {
    // Mouse / aiming
    var mouseSensX = 1.0f
    var mouseSensY = 1.0f
    var cursorRangeDp = 200f      // cursor distance from hero that equals a skill's full range
    var charX = 0.5f              // hero position on screen (fraction)
    var charY = 0.52f
    var rightClickMove = true
    var leftClickBinding = "attack"

    // Movement joystick
    var joyX = 0.13f
    var joyY = 0.70f
    var joyRadiusDp = 60f
    var joyPush = 0.9f            // how far toward the edge the stick is pushed
    var joySmooth = 0.3f          // 0 = instant, higher = smoother
    var moveDeadzoneDp = 40f      // right-click: ignore cursor this close to hero

    // Timing
    var frameMs = 30
    var tapMinMs = 50
    var aimSettleMs = 45
    var levelUpOffsetY = 0.11f    // Ctrl+skill taps this far above the skill button

    // Keys
    var toggleKey = KeyEvent.KEYCODE_F1
    var freeKey = KeyEvent.KEYCODE_GRAVE
    var editorKey = KeyEvent.KEYCODE_F3
    var keyUp = KeyEvent.KEYCODE_DPAD_UP
    var keyDown = KeyEvent.KEYCODE_DPAD_DOWN
    var keyLeft = KeyEvent.KEYCODE_DPAD_LEFT
    var keyRight = KeyEvent.KEYCODE_DPAD_RIGHT

    var packages = "com.riotgames.league.wildrift,com.tencent.lolm"
    var bindings: MutableList<Binding> = defaultBindings()

    fun packageList(): List<String> =
        packages.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("mouseSensX", mouseSensX.toDouble())
        o.put("mouseSensY", mouseSensY.toDouble())
        o.put("cursorRangeDp", cursorRangeDp.toDouble())
        o.put("charX", charX.toDouble())
        o.put("charY", charY.toDouble())
        o.put("rightClickMove", rightClickMove)
        o.put("leftClickBinding", leftClickBinding)
        o.put("joyX", joyX.toDouble())
        o.put("joyY", joyY.toDouble())
        o.put("joyRadiusDp", joyRadiusDp.toDouble())
        o.put("joyPush", joyPush.toDouble())
        o.put("joySmooth", joySmooth.toDouble())
        o.put("moveDeadzoneDp", moveDeadzoneDp.toDouble())
        o.put("frameMs", frameMs)
        o.put("tapMinMs", tapMinMs)
        o.put("aimSettleMs", aimSettleMs)
        o.put("levelUpOffsetY", levelUpOffsetY.toDouble())
        o.put("toggleKey", toggleKey)
        o.put("freeKey", freeKey)
        o.put("editorKey", editorKey)
        o.put("keyUp", keyUp)
        o.put("keyDown", keyDown)
        o.put("keyLeft", keyLeft)
        o.put("keyRight", keyRight)
        o.put("packages", packages)
        val arr = JSONArray()
        for (b in bindings) {
            val j = JSONObject()
            j.put("id", b.id)
            j.put("keyCode", b.keyCode)
            j.put("x", b.x.toDouble())
            j.put("y", b.y.toDouble())
            j.put("mode", b.mode.name)
            j.put("aimRadiusDp", b.aimRadiusDp.toDouble())
            arr.put(j)
        }
        o.put("bindings", arr)
        return o
    }

    fun load(o: JSONObject) {
        fun f(k: String, d: Float) = o.optDouble(k, d.toDouble()).toFloat()
        mouseSensX = f("mouseSensX", mouseSensX)
        mouseSensY = f("mouseSensY", mouseSensY)
        cursorRangeDp = f("cursorRangeDp", cursorRangeDp)
        charX = f("charX", charX)
        charY = f("charY", charY)
        rightClickMove = o.optBoolean("rightClickMove", rightClickMove)
        leftClickBinding = o.optString("leftClickBinding", leftClickBinding)
        joyX = f("joyX", joyX)
        joyY = f("joyY", joyY)
        joyRadiusDp = f("joyRadiusDp", joyRadiusDp)
        joyPush = f("joyPush", joyPush)
        joySmooth = f("joySmooth", joySmooth)
        moveDeadzoneDp = f("moveDeadzoneDp", moveDeadzoneDp)
        frameMs = o.optInt("frameMs", frameMs)
        tapMinMs = o.optInt("tapMinMs", tapMinMs)
        aimSettleMs = o.optInt("aimSettleMs", aimSettleMs)
        levelUpOffsetY = f("levelUpOffsetY", levelUpOffsetY)
        toggleKey = o.optInt("toggleKey", toggleKey)
        freeKey = o.optInt("freeKey", freeKey)
        editorKey = o.optInt("editorKey", editorKey)
        keyUp = o.optInt("keyUp", keyUp)
        keyDown = o.optInt("keyDown", keyDown)
        keyLeft = o.optInt("keyLeft", keyLeft)
        keyRight = o.optInt("keyRight", keyRight)
        packages = o.optString("packages", packages)
        val arr = o.optJSONArray("bindings") ?: return
        for (i in 0 until arr.length()) {
            val j = arr.optJSONObject(i) ?: continue
            val b = bindings.firstOrNull { it.id == j.optString("id") } ?: continue
            b.keyCode = j.optInt("keyCode", b.keyCode)
            b.x = j.optDouble("x", b.x.toDouble()).toFloat()
            b.y = j.optDouble("y", b.y.toDouble()).toFloat()
            b.aimRadiusDp = j.optDouble("aimRadiusDp", b.aimRadiusDp.toDouble()).toFloat()
            b.mode = try { CastMode.valueOf(j.optString("mode")) } catch (_: Exception) { b.mode }
        }
    }
}

object Store {
    @Volatile var settings = AppSettings()
    @Volatile var pendingEditor = false
    private const val PREFS = "wr_keymapper"

    fun load(ctx: Context) {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("settings", null) ?: return
        try {
            val s = AppSettings()
            s.load(JSONObject(raw))
            settings = s
        } catch (_: Exception) {
        }
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("settings", settings.toJson().toString()).apply()
    }
}

fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
