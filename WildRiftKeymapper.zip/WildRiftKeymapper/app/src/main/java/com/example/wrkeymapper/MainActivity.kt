package com.example.wrkeymapper

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var enabled by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.load(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen(enabled) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        enabled = serviceEnabled()
    }

    private fun serviceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, KeymapService::class.java)
        return flat.contains(cn.flattenToString(), true) || flat.contains(cn.flattenToShortString(), true)
    }
}

@Composable
fun Screen(enabled: Boolean) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val s = Store.settings

    key(version) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Wild Rift Keymapper", style = MaterialTheme.typography.headlineSmall)

            Section("Setup") {
                Text(
                    if (enabled) "Accessibility service: ENABLED" else "Accessibility service: not enabled",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    "1. Turn on WR Keymapper in Accessibility settings. If Android says \"Restricted setting\", " +
                        "open App info, tap the three-dot menu, and choose Allow restricted settings first.\n" +
                        "2. Connect a keyboard and mouse (USB-OTG or Bluetooth).\n" +
                        "3. Open Wild Rift with the button below and drag each marker onto its real button, then Save.\n" +
                        "4. In game the mouse is captured: move to aim, right-click to move toward the cursor, " +
                        "left-click to attack."
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility") }
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        )
                    }) { Text("App info") }
                }
                Button(onClick = { launchGameWithEditor(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open Wild Rift + layout editor")
                }
                Text(
                    "In game: ${keyName(s.toggleKey)} = mapping on/off, ${keyName(s.freeKey)} = free cursor " +
                        "(use for menus and chat), ${keyName(s.editorKey)} = layout editor. " +
                        "Ctrl + skill key = level up that skill."
                )
            }

            Section("Mouse and aiming") {
                SliderRow(ctx, "Mouse speed X", s.mouseSensX, 0.2f, 4f) { s.mouseSensX = it }
                SliderRow(ctx, "Mouse speed Y", s.mouseSensY, 0.2f, 4f) { s.mouseSensY = it }
                SliderRow(ctx, "Cursor distance = full skill range (dp)", s.cursorRangeDp, 80f, 500f) { s.cursorRangeDp = it }
                SliderRow(ctx, "Hero position X", s.charX, 0.2f, 0.8f) { s.charX = it }
                SliderRow(ctx, "Hero position Y", s.charY, 0.2f, 0.8f) { s.charY = it }
                SwitchRow(ctx, "Right-click moves toward cursor", s.rightClickMove) { s.rightClickMove = it }
            }

            Section("Movement stick") {
                SliderRow(ctx, "Stick radius (dp)", s.joyRadiusDp, 30f, 120f) { s.joyRadiusDp = it }
                SliderRow(ctx, "Stick push (fraction of radius)", s.joyPush, 0.3f, 1f) { s.joyPush = it }
                SliderRow(ctx, "Smoothing", s.joySmooth, 0f, 0.9f) { s.joySmooth = it }
                SliderRow(ctx, "Right-click dead zone (dp)", s.moveDeadzoneDp, 0f, 120f) { s.moveDeadzoneDp = it }
            }

            Section("Timing") {
                SliderRow(ctx, "Frame length (ms) - lower = more responsive", s.frameMs.toFloat(), 16f, 80f) { s.frameMs = it.toInt() }
                SliderRow(ctx, "Minimum tap hold (ms)", s.tapMinMs.toFloat(), 20f, 200f) { s.tapMinMs = it.toInt() }
                SliderRow(ctx, "Aim settle before cast (ms)", s.aimSettleMs.toFloat(), 0f, 150f) { s.aimSettleMs = it.toInt() }
                SliderRow(ctx, "Level-up button offset above skill", s.levelUpOffsetY, 0.04f, 0.2f) { s.levelUpOffsetY = it }
            }

            Section("Hotkeys and movement keys") {
                KeyRow(ctx, "Mapping on/off", s.toggleKey) { s.toggleKey = it }
                KeyRow(ctx, "Free cursor", s.freeKey) { s.freeKey = it }
                KeyRow(ctx, "Layout editor", s.editorKey) { s.editorKey = it }
                KeyRow(ctx, "Stick up", s.keyUp) { s.keyUp = it }
                KeyRow(ctx, "Stick down", s.keyDown) { s.keyDown = it }
                KeyRow(ctx, "Stick left", s.keyLeft) { s.keyLeft = it }
                KeyRow(ctx, "Stick right", s.keyRight) { s.keyRight = it }
            }

            Section("Buttons") {
                for (b in s.bindings) BindingCard(ctx, b)
            }

            Section("Game packages") {
                var pk by remember { mutableStateOf(s.packages) }
                OutlinedTextField(
                    value = pk,
                    onValueChange = { pk = it; s.packages = it; Store.save(ctx) },
                    label = { Text("Comma-separated package names") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedButton(
                onClick = { Store.settings = AppSettings(); Store.save(ctx); version++ },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Reset everything to defaults") }
        }
    }
}

private fun launchGameWithEditor(ctx: Context) {
    val pm = ctx.packageManager
    val intent = Store.settings.packageList().firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
    if (intent == null) {
        Toast.makeText(ctx, "Wild Rift is not installed (check the package names below)", Toast.LENGTH_LONG).show()
        return
    }
    Store.pendingEditor = true
    ctx.startActivity(intent)
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun SliderRow(ctx: Context, label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    var v by remember { mutableFloatStateOf(value.coerceIn(min, max)) }
    Column {
        Text(label + ": " + "%.2f".format(v))
        Slider(
            value = v,
            onValueChange = { v = it; onChange(it) },
            onValueChangeFinished = { Store.save(ctx) },
            valueRange = min..max
        )
    }
}

@Composable
fun SwitchRow(ctx: Context, label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(value) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; onChange(it); Store.save(ctx) })
    }
}

@Composable
fun KeyRow(ctx: Context, label: String, code: Int, onChange: (Int) -> Unit) {
    var cur by remember { mutableIntStateOf(code) }
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        OutlinedButton(onClick = { open = true }) { Text(keyName(cur)) }
    }
    if (open) {
        KeyCaptureDialog(label, onDismiss = { open = false }) {
            cur = it; onChange(it); Store.save(ctx); open = false
        }
    }
}

@Composable
fun BindingCard(ctx: Context, b: Binding) {
    var key by remember { mutableIntStateOf(b.keyCode) }
    var mode by remember { mutableStateOf(b.mode) }
    var open by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(b.label, style = MaterialTheme.typography.titleSmall)
                OutlinedButton(onClick = { open = true }) { Text(keyName(key)) }
            }
            if (b.canAim) {
                TextButton(onClick = {
                    val next = CastMode.values()[(mode.ordinal + 1) % CastMode.values().size]
                    mode = next; b.mode = next; Store.save(ctx)
                }) { Text("Mode: " + mode.label) }
                if (mode != CastMode.TAP) {
                    SliderRow(ctx, "Aim drag radius (dp)", b.aimRadiusDp, 40f, 200f) { b.aimRadiusDp = it }
                }
            }
        }
    }
    if (open) {
        KeyCaptureDialog(b.label, onDismiss = { open = false }) {
            key = it; b.keyCode = it; Store.save(ctx); open = false
        }
    }
}

@Composable
fun KeyCaptureDialog(title: String, onDismiss: () -> Unit, onKey: (Int) -> Unit) {
    val fr = remember { FocusRequester() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Rebind: $title") },
        text = {
            Box(
                Modifier.fillMaxWidth().height(80.dp)
                    .onKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown) { onKey(e.nativeKeyEvent.keyCode); true } else false
                    }
                    .focusRequester(fr)
                    .focusable(),
                contentAlignment = Alignment.Center
            ) { Text("Press a key on your keyboard...") }
            LaunchedEffect(Unit) { fr.requestFocus() }
        }
    )
}
